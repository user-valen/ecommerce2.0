package com.uade.tpo.ecommerce.entity;

public enum Role {
    USER, ADMIN
}
