package com.uade.tpo.ecommerce.entity;

public enum CategoryType {
    APPLE,
    SAMSUNG,
    XIOMI
}
