package com.uade.tpo.ecommerce.entity;

public enum OrderStatus {
    PENDING, PAID, CANCELLED
}
